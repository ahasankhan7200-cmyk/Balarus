# Balarus Spare House ERP — SQLite fix

This version keeps SQLite and the local `balarus.db` database; it does not require PostgreSQL or Supabase.

## Streamlit Cloud
- Main file path: `app.py`
- Add this to Settings → Secrets:

```toml
APP_PASSWORD = "set-a-strong-password"
```

Upload `app.py` and `requirements.txt` to the repository root, then commit.

**Persistence warning:** Streamlit Cloud's local filesystem may reset on rebuild/redeploy or restart. Download backups regularly from the app's Backup page. This fix does not migrate existing database records.
