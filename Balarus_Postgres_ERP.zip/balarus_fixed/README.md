# Balarus Spare House ERP — PostgreSQL edition

This version stores your ERP data in hosted PostgreSQL (recommended: Supabase), not in a local SQLite file.

## 1. Create your database
1. Create a Supabase project at https://supabase.com.
2. Open **Project Settings → Database**. Copy the connection string (use the pooler connection if your hosting network needs it).
3. For Streamlit Cloud, prefer the Supabase **Session pooler** connection string (usually port 5432) if the direct endpoint is unreachable from an IPv4 network. Keep the connection string private.

## 2. Deploy on Streamlit Cloud
1. Upload `app.py` and `requirements.txt` to your GitHub repository.
2. Streamlit Cloud → App settings → **Secrets**. Add:  
   ```toml
   APP_PASSWORD = "use-a-long-unique-password"
   DATABASE_URL = "postgresql://...your-private-connection-string..."
   ```
3. Set **Main file path** to `app.py`, then deploy/reboot.
4. The app creates its tables and Cash/Bank/bKash accounts on first launch.

## Important security notes
- Never commit your `DATABASE_URL` or password into GitHub.
- Use a strong app password and change it if it has been shared.
- Supabase free tier may pause inactive projects and has its own backup/retention limits. Check its plan and configure database backups.
- The in-app backup creates a ZIP of CSV table exports. It is not a full PostgreSQL backup.
- Existing SQLite records are not automatically migrated. Export your old database/CSV files before switching; migration can be done separately.

## Included
Dashboard, inventory, retail/wholesale sales, purchases, parties, accounts, expenses, transfers, due settlements, reports, and CSV ZIP backup.
