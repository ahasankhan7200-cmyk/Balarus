# Balarus Spare House ERP (fixed build)

## Run locally
1. Install Python 3.10+.
2. Open a terminal in this folder and run `pip install -r requirements.txt`.
3. Set an app password:
   - Windows PowerShell: `$env:APP_PASSWORD="use-a-long-unique-password"`
   - macOS/Linux: `export APP_PASSWORD="use-a-long-unique-password"`
4. Run `streamlit run app.py`.

## Streamlit Cloud
- Set **Main file path** to `app.py`.
- In app Settings → Secrets, add:
  ```toml
  APP_PASSWORD = "use-a-long-unique-password"
  ```
- This build uses SQLite at `balarus.db` by default. Local SQLite files on Streamlit Cloud may not persist through restarts/redeployments. Do not enter important real transactions until a persistent database is configured and tested. Download a backup from the app's Backup page regularly.

## Included
Dashboard, products/stock, sales, purchases, customers/suppliers, expenses, account transfers, due settlements, reports, CSV exports, database backup download.

## Important limitations
This is an early-stage bookkeeping/inventory tool, not audited accounting software. It does not yet provide invoice printing, sales/purchase returns, transaction editing/voids, user roles, multi-branch inventory, a proper persistent hosted database integration, or a full accounting ledger. Profit is an estimate.
